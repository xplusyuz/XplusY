// ==================== GLOBAL FUNCTIONS (Modal uchun) ====================
        window.openMathModal = modalManager.openMathModal.bind(modalManager);
        window.closeMathModal = modalManager.closeMathModal.bind(modalManager);
        window.saveMathAnswer = modalManager.saveMathAnswer.bind(modalManager);
        window.enableMandatoryFullScreen = fullscreenManager.enable.bind(fullscreenManager);
