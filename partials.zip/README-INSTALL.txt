Tez integratsiya yo'riqnomasi (v2)

1) ZIP ichidagilarni saytingizga qo'ying:
   - partials/tests.html
   - js/tests.js
   - css/tests.css
   - csv/tests.csv
   - csv/tests/dtm_demo.csv

2) router.js ichiga quyidagini qo'shing:
   (router-snippet.txt faylida tayyor blok bor)

3) Netlify’da kesh muammosi bo‘lsa, F5 bilan qayta yuklang yoki `?v=2` query qo‘shing.

4) Manifest:
   csv/tests.csv — ustun: file. Misol: /csv/tests/dtm_demo.csv

5) Deep-link: #/tests?src=/csv/tests/dtm_demo.csv
