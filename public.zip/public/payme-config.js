// Payme config (edit this file)
// PAYME_MERCHANT_ID is shown in Payme Business cabinet (merchant / kassа settings).
// Example format: "66f3c0c0..." (string)
export const PAYME_MERCHANT_ID = "YOUR_PAYME_MERCHANT_ID";

// Language sent to Payme checkout: uz / ru / en
export const PAYME_LANG = "uz";
