XplusY Firebase Site: home.html, courses.html, simulators.html, tests.html, admin.html
