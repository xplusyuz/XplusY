# XplusY Firebase v2
1) assets/js/firebase-init.js config
2) Rules ni qo'ying
3) Admin orqali yozing
4) Public sahifalar Firestore'dan o'qiydi
