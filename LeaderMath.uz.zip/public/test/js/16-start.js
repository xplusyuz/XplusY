// ==================== START APP ====================
        document.addEventListener('DOMContentLoaded', app.initialize.bind(app));
