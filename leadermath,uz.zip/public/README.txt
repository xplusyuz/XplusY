
LeaderMath minimal test.html

Ishlatish:
/test.html?id=math001&code=8888

Talablar:
- public/authUtils.js mavjud bo‘lishi kerak
- Netlify API /tests/get va /tests/submit endpointlar ishlashi kerak
