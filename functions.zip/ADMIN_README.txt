ORZUMALL ADMIN (SECURE)
====================

Kirish:
- /admin/login.html  (Google popup)
- Faqat: sohibjonmath@gmail.com

Panel:
- /admin/panel.html (to‘liq yopiq guard bilan)

Eslatma:
1) Firestore rules: firestore.rules.txt ni Firebase console -> Firestore Rules ga qo‘ying.
2) Hosting/Netlify: admin papka public bo‘lishi mumkin, lekin ko‘rinishi/authsiz ochilmaydi.
3) Boshqa gmail bilan kirilsa: avtomatik signOut + redirect.

